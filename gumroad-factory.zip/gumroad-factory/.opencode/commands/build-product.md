---
description: Build all product files for a slug — creates products/{slug}/src/
agent: agent-3-builder
subtask: true
---

Build the product: $ARGUMENTS

Steps:
1. Read ideas/validated/{slug}_research.json for context
2. Create products/{slug}/src/ directory
3. Build all product files per type standards
4. Verify quality gate (README, no paid APIs required, tested if script)
5. Report: "Build complete. Run: /package {slug}"

If $ARGUMENTS is empty, ask operator for the slug and product concept.
