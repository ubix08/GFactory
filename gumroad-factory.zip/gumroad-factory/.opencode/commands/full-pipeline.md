---
description: End-to-end pipeline for a slug — validate → build → package → publish
agent: agent-3-builder
subtask: true
---

Run the full pipeline for: $ARGUMENTS

Execute in sequence:
1. @agent-2-researcher → /validate {slug}
2. @agent-3-builder → /build-product {slug}
3. @agent-4-packager → /package {slug}
4. @agent-5-publisher → /publish {slug}

Pause after each step for operator confirmation before proceeding.
Stop immediately if any step fails or returns errors.

If $ARGUMENTS is empty, ask operator for the slug and product concept.
