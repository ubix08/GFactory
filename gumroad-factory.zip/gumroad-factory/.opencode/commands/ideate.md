---
description: Interactive idea selection — pick the best product to build today
agent: agent-1-ideator
subtask: true
---

Help operator choose today's product.

Steps:
1. Run score if ideas/scored_ideas.json is empty
2. Show top 5 ACCEPT ideas as a decision table
3. Ask operator: "Which should we build today? Reply with number or describe your own."
4. After selection, suggest: /validate {slug}

Also show Standard Product Library (P04, P05) as quick-start options.
