---
description: Record a sale, refund, or live event in the revenue tracker
agent: agent-5-publisher
subtask: true
---

Log a sale event: $ARGUMENTS

Usage: /log-sale <event> <slug> <amount>
Events: sale | refund | live
Example: /log-sale sale upwork-proposal-templates 15

Run: python scripts/log_sale.py {event} {slug} {amount}
Then show updated tracker.md summary.

If $ARGUMENTS is empty, ask: "What event? (sale / refund / live), which slug, and what amount?"
