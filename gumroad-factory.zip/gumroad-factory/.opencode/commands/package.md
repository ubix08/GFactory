---
description: Package ZIP + write Gumroad listing copy for a product slug
agent: agent-4-packager
subtask: true
---

Package the product: $ARGUMENTS

Steps:
1. Run: python scripts/package_product.py {slug}
2. Write products/{slug}/listing.md with full Gumroad copy
3. Generate thumbnail prompt
4. Verify ZIP was created
5. Report: "Package complete. Run: /publish {slug}"

If $ARGUMENTS is empty, ask operator for the slug.
