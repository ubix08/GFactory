---
description: Publish product to Gumroad and log the launch
agent: agent-5-publisher
subtask: true
---

Publish the product to Gumroad: $ARGUMENTS

Steps:
1. Pre-flight: verify ZIP and listing.md are complete
2. Run: python scripts/publish_gumroad.py {slug}
3. Run: python scripts/log_sale.py live {slug} 0
4. Report product URL

If $ARGUMENTS is empty, ask operator for the slug.
