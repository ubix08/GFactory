---
description: One-time scaffold — create the full Gumroad Factory project structure
agent: agent-3-builder
subtask: true
---

Create the full Gumroad Factory project structure from scratch.

This command should be run ONCE in an empty directory to initialize the project.

Steps:
1. Create all directories: ideas/validated, products, sales, logs, scripts, .opencode/agents, .opencode/commands, .opencode/context/factory
2. Initialize JSON files: ideas/raw_signals.json, ideas/scored_ideas.json, ideas/rejected_ideas.json, ideas/seen_signals.json, sales/stats.json → all set to []
3. Create sales/tracker.md with empty dashboard
4. Confirm structure is complete

Note: All scripts, agents, commands, and context docs should already exist if you're reading this command. If they don't, the ZIP package may be incomplete.
