---
description: Run trend scanner — collect fresh pain signals from Reddit, HN, and Google Trends
agent: agent-0-scout
subtask: true
---

Run the trend scanner to collect pain signals.

Steps:
1. Run: python scripts/trend_scan.py
2. Show top 10 pain signals from the output
3. Recommend strongest signals to pass to /ideate
