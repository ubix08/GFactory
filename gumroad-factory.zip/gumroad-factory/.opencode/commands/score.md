---
description: Score raw signals and classify ideas as ACCEPT / HOLD / REJECT
agent: agent-1-ideator
subtask: true
---

Score all unscored signals in ideas/raw_signals.json.

Steps:
1. Run: python scripts/score_ideas.py
2. Show scoring summary (ACCEPT / HOLD / REJECT counts)
3. Display top 5 ACCEPT ideas
