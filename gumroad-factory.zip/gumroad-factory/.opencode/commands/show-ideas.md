---
description: Display current scored ideas table — top ACCEPT ideas ranked by score
agent: agent-1-ideator
subtask: true
---

Show the current ideas pipeline.

Steps:
1. Read ideas/scored_ideas.json
2. Display top 5 ACCEPT ideas sorted by total score
3. Show counts: ACCEPT / HOLD / REJECT
4. Suggest next action based on pipeline state
