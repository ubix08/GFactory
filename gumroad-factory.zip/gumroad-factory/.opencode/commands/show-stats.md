---
description: Show revenue dashboard — products live, total revenue, goal progress
agent: agent-5-publisher
subtask: true
---

Display the revenue dashboard.

Run: cat sales/tracker.md
Display it in full.

If no sales data exists yet, show the empty dashboard and remind operator
to run /publish to get first product live.
