---
description: Research demand for a specific product idea using Brave Search
agent: agent-2-researcher
subtask: true
---

Validate demand for product idea: $ARGUMENTS

Steps:
1. Search Gumroad for competing products
2. Search Reddit for demand evidence
3. Check purchase intent signals
4. Write ideas/validated/{slug}_research.json
5. Report green_light decision with evidence

If $ARGUMENTS is empty, ask operator for the slug.
