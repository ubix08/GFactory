# Gumroad Factory — System Overview

## Mission
Build and publish one digital product per day on Gumroad.
Target: $1 first week → $100 first month → $500/month by month 3.

## Core Principle
**One sharp pain. One specific person. One afternoon to build.**

Every product must pass the "5-dollar skip test":
> Would a busy professional pay $5 to skip the 2 hours it took to build this?

If yes → ship it.

## Architecture

```
Layer 1 — Python Scripts (scripts/)
  $0 LLM cost. Runs on cron or CLI command.
  trend_scan.py → score_ideas.py → package_product.py → publish_gumroad.py

Layer 2 — OpenCode Agents (.opencode/agents/)
  LLM-powered. Invoked via /command or @mention.
  scout → ideator → researcher → builder → packager → publisher

Layer 3 — Context Docs (.opencode/context/factory/)
  Agent reference knowledge. Read-only.
```

## Daily Workflow

```
Morning:
  /scan          ← fresh pain signals
  /ideate        ← pick today's product

Afternoon:
  /validate {slug}      ← confirm demand exists
  /build-product {slug} ← create the files
  /package {slug}       ← ZIP + listing copy
  /publish {slug}       ← go live on Gumroad

Evening:
  /show-stats           ← check dashboard
```

## Pipeline Command Map

| Command | Agent | What Happens |
|---------|-------|--------------|
| /scan | agent-0-scout | Runs trend_scan.py, reports top signals |
| /score | agent-1-ideator | Runs score_ideas.py, shows ACCEPT ideas |
| /ideate | agent-1-ideator | Interactive product selection |
| /validate {slug} | agent-2-researcher | Brave Search demand validation |
| /build-product {slug} | agent-3-builder | Creates all src/ files |
| /package {slug} | agent-4-packager | ZIP + listing.md |
| /publish {slug} | agent-5-publisher | Gumroad API + log live |
| /log-sale | agent-5-publisher | Record sale/refund events |
| /show-stats | agent-5-publisher | Revenue dashboard |
| /full-pipeline {slug} | agent-3-builder | All steps in sequence |

## Product Types Supported

| Type | Format | Build Time |
|------|--------|------------|
| script | Python CLI .py | 1-2 hrs |
| prompt_pack | .md with 10-20 prompts | 1-2 hrs |
| template | .xlsx or .md | 2-3 hrs |
| cheatsheet | .md single page | 1-2 hrs |
| guide | .md 800-2000 words | 2-3 hrs |
| micro_tool | Python multi-file CLI | 3-5 hrs |

## Revenue Tracker

Files:
- `sales/stats.json` — all events (live, sale, refund)
- `sales/tracker.md` — generated dashboard

Goal tracking:
- Week 1: $1 (first sale)
- Month 1: $100
- Month 3: $500/month

## Tool Hierarchy (by cost)

1. **Free, always-on:** Python scripts (trend_scan, score, package)
2. **Cheap, low-frequency:** Haiku agents (scout, ideator)
3. **Moderate, per-product:** Sonnet agents (researcher, builder, packager, publisher)
4. **Free, CLI:** run_factory.py orchestrator

## VPS Resource Budget

| Process | CPU | RAM |
|---------|-----|-----|
| OpenCode runtime | 1 core | ~500MB |
| trend_scan.py | 0.2 core | ~50MB |
| score_ideas.py | 0.1 core | ~30MB |
| Total active | <2 cores | <1GB |

Fits comfortably on Contabo 4-core / 7GB VPS.
