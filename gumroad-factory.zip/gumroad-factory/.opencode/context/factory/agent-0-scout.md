# Scout Agent Reference — Trend Sources & Signal Scoring

## Signal Sources

### Reddit RSS Feeds
Direct RSS — no auth required.

| Subreddit | URL | Primary Pain Keywords |
|-----------|-----|-----------------------|
| r/entrepreneur | https://www.reddit.com/r/entrepreneur/new.rss | "wish there was", "no good solution" |
| r/digitalnomad | https://www.reddit.com/r/digitalnomad/new.rss | "template", "how do I" |
| r/consulting | https://www.reddit.com/r/consulting/new.rss | "deliverable", "proposal", "every project" |
| r/sap | https://www.reddit.com/r/sap/new.rss | "annoying", "manually", "automate" |
| r/excel | https://www.reddit.com/r/excel/new.rss | "hours", "repetitive", "tedious" |
| r/learnpython | https://www.reddit.com/r/learnpython/new.rss | "frustrated", "how do I" |
| r/freelance | https://www.reddit.com/r/freelance/new.rss | "template", "proposal", "contract" |
| r/Upwork | https://www.reddit.com/r/Upwork/new.rss | "proposal", "win rate", "template" |

### Hacker News Algolia API
Endpoint: `https://hn.algolia.com/api/v1/search_by_date?query={term}&tags=story`

Best search terms: `pain`, `tedious`, `automate`, `template`, `annoying`, `wish`

### Google Trends RSS
Endpoint: `https://trends.google.com/trends/trendingsearches/daily/rss?geo=US`
Filter for operator-relevant keywords: CSV, Python, SAP, automation, ERP, Excel

## Signal Strength Rubric

| Signal | Strength | Score Boost |
|--------|----------|-------------|
| Upvotes > 100 | Very High | +2 to pain score |
| Upvotes 20-100 | High | +1 to pain score |
| Contains "every day" or "hours" | High | +2 to pain score |
| Contains "hate" or "frustrated" | High | +1.5 to pain score |
| Contains "does anyone else" | Medium | +1 |
| ERP/SAP/Excel/Python keyword | High fit | +1.5 to operator_fit |
| Contains "manually" or "repetitive" | High buildability | +1 to buildability |

## Deduplication
MD5 hash of `(title + url)`. Stored in `ideas/seen_signals.json`.
New hash = new signal. Same hash = skip silently.

## What to Flag Immediately
Signals mentioning these are high-priority — flag at top of report:
- SAP, FICO, ABAP, S/4HANA
- Excel automation, CSV cleaning
- Upwork proposal, freelance contract
- Python for beginners
- n8n, Zapier, Make.com workflows
