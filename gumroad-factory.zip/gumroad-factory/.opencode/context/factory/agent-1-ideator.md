# Ideator Agent Reference — Scoring Formula & Niche Map

## Scoring Formula

```
total = (pain × 0.35) + (buildability × 0.30) + (monetizability × 0.25) + (operator_fit × 0.10)
```

Each dimension is scored 0-10:

### Pain Score (0-10)
Measures how acute and specific the pain is.
- 9-10: "I spend 3 hours every day doing this manually"
- 7-8: "This is really annoying, wish there was a tool"
- 5-6: "It would be nice if..."
- 3-4: Vague frustration, no specifics
- 1-2: Not really a pain, just a preference

### Buildability Score (0-10)
Can this be built as a file deliverable in under 4 hours?
- 9-10: Simple Python script or markdown template, zero dependencies
- 7-8: Multi-file Python tool or Excel template with logic
- 5-6: Doable but needs research or external data
- 3-4: Complex, multiple moving parts
- 1-2: Requires SaaS, backend, or real-time data

### Monetizability Score (0-10)
Would someone pay for this?
- 9-10: Professional context, clear time/money saved, recurring need
- 7-8: Professional tool, nice-to-have but valuable
- 5-6: Hobbyist or student context
- 3-4: Free alternatives exist and are good enough
- 1-2: No clear buyer or willingness to pay

### Operator Fit (0-10)
Matches operator's skills (ERP/SAP, Python, consulting, business process).
- 9-10: Core domain (SAP, ERP, consulting, Excel, Python scripting)
- 7-8: Adjacent domain (freelancing, data analysis, automation)
- 5-6: Generic professional tool
- 3-4: Outside operator's expertise
- 1-2: Completely foreign domain

## Decision Rules
- Score ≥ 7.0 → **ACCEPT** — build this
- Score 4.0–6.9 → **HOLD** — could work with refinement
- Score < 4.0 → **REJECT** — move on

## REJECT Overrides (regardless of score)
If any of these apply, REJECT immediately:
1. Requires SaaS subscription to DELIVER (not just build)
2. Requires social following or audience to monetize
3. Implies ongoing support ("maintain this", "update weekly")
4. Legal or compliance product (liability risk)
5. Requires paid API key to USE the product

## Priority Niche Map

| Priority | Niche | Buyer | Core Pain | Best Product Type | Price Range |
|----------|-------|-------|-----------|------------------|-------------|
| 1 | ERP/SAP Consulting | Freelance SAP consultants | No reusable deliverables, reinventing every project | Template pack | $25–$49 |
| 2 | Python Beginners | Self-taught devs | No structured practice with feedback | Prompt pack / guide | $9–$19 |
| 3 | Excel Power Users | Office analysts | Repetitive tasks, no automation | Python script | $9–$25 |
| 4 | Freelancers | Solo service providers | Proposal/contract boilerplate from scratch | Template pack | $9–$19 |
| 5 | No-Code Automation | n8n/Zapier builders | Workflow templates scattered/undocumented | Template JSON pack | $15–$39 |
| 6 | Data Analysts | Junior analysts | Manually cleaning messy CSVs | Python script | $9–$25 |
| 7 | AI Prompt Users | Knowledge workers | Prompt engineering from scratch | Prompt pack | $5–$15 |

## Standard Product Library (Pre-Validated)

| ID | Slug | Product | Niche | Type | Price | Hours |
|----|------|---------|-------|------|-------|-------|
| P01 | sap-kickoff-template-pack | SAP Project Kickoff Template Pack | ERP Consulting | Template | $39 | 4 |
| P02 | python-csv-cleaner | Python CSV Cleaner CLI | Data Analysts | Script | $15 | 2 |
| P03 | claude-prompts-for-consultants | Claude Prompts for Consultants | Freelancers | Prompt Pack | $19 | 3 |
| P04 | upwork-proposal-templates | Upwork Proposal Templates (5 niches) | Freelancers | Template | $15 | 2 |
| P05 | sap-fico-cheatsheet | SAP FICO Cheatsheet | SAP Beginners | Cheatsheet | $9 | 2 |
| P06 | python-for-erp-consultants | Python for ERP Consultants — 30 Scripts | ERP + Python | Script Pack | $49 | 6 |
| P07 | n8n-workflow-templates | n8n Workflow Templates (10 flows) | No-Code | Template JSON | $25 | 3 |
| P08 | excel-to-python-guide | Excel → Python Migration Guide | Excel Power Users | Guide | $15 | 3 |

**Start here:** P04 or P05 — 2 hours each, operator knows both domains deeply.
