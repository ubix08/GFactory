# Researcher Agent Reference — Demand Validation Playbook

## Validation Objective
Confirm that real people have this pain AND would pay for a file-based solution before we spend 2-4 hours building.

A green_light requires:
1. ≥2 confirmed demand signals (forum threads, questions, upvoted posts)
2. Either: competition_count < 5 OR clear positioning advantage over existing products

## Brave Search Query Templates

### Step 1 — Competition Check
Query: `"{product topic}" gumroad`
Query: `"{product topic}" etsy digital download`
Query: `"{product topic}" buy template`

Count results. Note:
- How many exist on Gumroad/Etsy?
- What are they priced at?
- Are they high quality or low effort?
- Is there a clear gap (price, quality, niche specificity)?

### Step 2 — Demand Evidence
Query: `"{pain keyword}" site:reddit.com`
Query: `"{product topic}" reddit frustrated OR annoying OR hours`
Query: `"{product topic}" forum "how do I" OR "wish there was"`

Look for:
- Posts with 10+ upvotes expressing the pain
- Threads where no solution is recommended
- "I've been doing this manually for years"
- Questions with many comments = high interest

### Step 3 — Purchase Intent
Query: `"{product topic}" "free template" OR "looking for template"`
Query: `"{product type}" for "{target buyer}"  buy`

Look for:
- People asking for exactly this product
- Forum posts where the answer is "I can't find a good one"
- Requests for recommendations with no good answers

## Competition Analysis Framework

| Competition Level | Count | Action |
|------------------|-------|--------|
| Blue ocean | 0-2 products | Build immediately — clear gap |
| Light | 3-5 products | Build if we can be better/cheaper/more specific |
| Moderate | 6-10 products | Need clear differentiation angle |
| Crowded | 11+ products | HOLD unless we have strong unique angle |

## Pricing Benchmarks by Niche

| Niche | Typical Gumroad Price | Our Target |
|-------|----------------------|------------|
| SAP/ERP templates | $20-$60 | $25-$49 |
| Excel/spreadsheet tools | $5-$25 | $9-$25 |
| Python scripts | $5-$20 | $9-$15 |
| Freelance templates | $5-$25 | $9-$19 |
| Prompt packs | $5-$15 | $5-$15 |
| No-code workflows | $10-$40 | $15-$25 |

## Research JSON Schema
Write to `ideas/validated/{slug}_research.json`:

```json
{
  "slug": "product-slug",
  "validated": true,
  "competition_count": 3,
  "competition_price_range": "$9-$25",
  "demand_evidence": [
    "reddit.com/r/sap/comments/... — 47 upvotes, 'I do this manually every project'",
    "reddit.com/r/consulting/comments/... — Thread: 'SAP project templates?'"
  ],
  "positioning": "More specific to SAP FICO module vs generic ERP templates",
  "recommended_price": 25,
  "green_light": true,
  "notes": "3 competing products on Gumroad but all are generic. Strong Reddit demand for SAP-specific templates."
}
```

## Green Light Checklist
- [ ] ≥2 demand evidence sources found
- [ ] Competition is <5 OR we have clear differentiation
- [ ] Pricing fits the $5-$49 range
- [ ] Product type is buildable (file, not service)
- [ ] No legal/compliance risk

## Automatic HOLD signals
- Competition is saturated (10+) with high-quality products
- No demand evidence found after 3 search attempts
- Pain is real but buyers are getting it free elsewhere
