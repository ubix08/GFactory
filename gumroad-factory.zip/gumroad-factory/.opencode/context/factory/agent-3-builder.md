# Builder Agent Reference — Product Type Guides & Quality Standards

## Build Philosophy
Every product must pass the "5-dollar skip test":
> Would a busy professional pay $5 to skip the 2 hours it took to build this?

If yes → build it well and ship it.

## Build Guide by Product Type

---

### Script (Python CLI)
**Target:** Saves repetitive Python/data work. Zero setup friction for buyer.

Structure:
```
products/{slug}/src/
├── {name}.py          ← main script with argparse
├── requirements.txt   ← one dep per line, pinned versions preferred
└── README.md
```

Script standards:
- Top docstring: "What: / Input: / Output: / Usage: python {name}.py --input file.csv"
- argparse with `--help` fully documented
- All file I/O wrapped in try/except with friendly error messages
- Validate inputs early: file exists? correct format?
- Print progress with rich or print() — no silent failures
- Exit code 0 on success, 1 on error

README structure:
```markdown
# {Product Name}
One-line description of what it solves.

## What It Does
2-3 sentences.

## Requirements
pip install -r requirements.txt

## Usage
python {name}.py --input data.csv --output cleaned.csv

## Example
Input:  messy.csv (3000 rows, mixed formats)
Output: clean.csv (2847 rows, standardized)

## What Gets Fixed
- Removes empty rows
- Standardizes date formats
- Trims whitespace
```

---

### Prompt Pack
**Target:** Saves prompt engineering time for a specific role/use case.

Structure:
```
products/{slug}/src/
├── prompts.md   ← all prompts
└── README.md
```

prompts.md structure:
```markdown
# {Title}: Prompt Pack for {Target Role}

## Who This Is For
{1-2 sentences on the target buyer and use case}

## How to Use
{3 steps to get value from these prompts}

---

## Section 1: {Category Name}

### Prompt 1: {Action-oriented title}
**Context:** {When to use this prompt}
**The Prompt:**
> {The actual prompt text — make it copy-pasteable}
**Expected Output:** {What a good response looks like}

### Prompt 2: ...
```

Minimum 10 prompts. Target 15-20. Group into 3-5 categories.

---

### Template (Excel)
**Target:** Saves setup/formatting time on recurring professional documents.

Build with openpyxl:
```python
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

wb = Workbook()
ws = wb.active
ws.title = "Template"

# Add Instructions tab
ws_inst = wb.create_sheet("Instructions")

wb.save("products/{slug}/src/template.xlsx")
```

Standards:
- Pre-filled column headers (bold, colored)
- One example row showing format
- Instructions tab explaining each column
- Data validation where helpful (dropdowns for status fields)
- Freeze top row

---

### Cheatsheet
**Target:** Single-page reference for a complex topic. Print-ready.

Structure:
```markdown
# {Topic} Cheatsheet

> Quick reference for {target user}. Last updated {date}.

## Section 1: {Core Concept}
| Item | Meaning | Example |
|------|---------|---------|
| ... | ... | ... |

## Section 2: {Common Operations}
...

## Common Mistakes
| Mistake | Why It Happens | Fix |
|---------|---------------|-----|

## Quick Examples
```{code or example}```
```

Rule: Every row must be actionable. No vague entries like "Use best practices."

---

### Guide
**Target:** Step-by-step walkthrough of a process or skill.

Structure:
```markdown
# {Title}: {Subtitle with benefit}

**Who this is for:** {1 sentence}
**What you'll be able to do:** {1 sentence}
**Time to read:** {X minutes}

---

## 1. {Section Title}
{Concept in 2-3 sentences}

**Example:**
{Concrete example}

**Your action step:**
> {What to do right now}

## 2. ...

---

## Quick Reference
| Step | What to Do | Common Mistake |
|------|-----------|----------------|
```

---

### Micro-Tool (Multi-file CLI)
**Target:** More powerful than a script — handles complex workflows.

Structure:
```
products/{slug}/src/
├── main.py         ← entry point, argparse
├── utils.py        ← helper functions
├── requirements.txt
├── sample_input/
│   └── example.csv
└── README.md
```

README ASCII demo:
```
$ python main.py --input sample_input/example.csv --output result.json

✓ Loaded 1,247 rows
✓ Processed 1,201 rows
✗ Skipped 46 rows (missing required fields)
✓ Output written to result.json

Done in 1.2 seconds
```

## Quality Gate Checklist
Before marking any build complete, verify ALL of these:
- [ ] `products/{slug}/src/README.md` exists and is complete
- [ ] Product delivers on its stated promise (re-read the concept)
- [ ] No external paid API required to USE the product
- [ ] Script: tested with `python {file}.py --help` (no errors)
- [ ] Script: tested with actual sample data
- [ ] All files inside `products/{slug}/src/` — none missing
- [ ] No `[PLACEHOLDER]`, `[TODO]`, or `[FILL IN]` left unresolved
- [ ] requirements.txt exists for all Python products

## Common Mistakes to Avoid
1. Building too much — a 10-prompt pack is fine; don't expand to 50
2. Adding external API calls — buyer shouldn't need API keys
3. Skipping the README — buyers need to know how to use it
4. No error handling — scripts that crash with a traceback feel amateur
5. Vague cheatsheet entries — every row must be actionable
