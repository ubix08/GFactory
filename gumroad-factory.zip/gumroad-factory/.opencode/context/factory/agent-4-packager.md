# Packager Agent Reference — ZIP Standards, Listing Formulas, Thumbnails

## ZIP Structure Standards

Every product ZIP must contain:
```
{slug}_v1.zip
├── README.md                   ← always required
├── {main deliverable}          ← the product itself
├── requirements.txt            ← if Python product
└── preview_{slug}.md           ← NOT in ZIP, separate file in dist/
```

Rules:
- No nested ZIP files inside the ZIP
- No `.DS_Store`, `__pycache__/`, `*.pyc` files
- README must be at root of ZIP, not inside a subfolder
- Maximum ZIP size: 250MB (Gumroad limit)

## listing.md Format (Required Sections)

Write exactly these 5 sections, in order:

```
# TITLE
{product title}

# DESCRIPTION
{150-300 word description}

# PRICE
{integer cents, e.g. 1500 for $15.00}

# TAGS
{lowercase, comma-separated, 5-8 tags}

# SUMMARY
{one line, under 100 characters}
```

## Listing Copy Formula

### TITLE Formula
Pattern: `{What it is} — {Benefit/Quantity/Who it's for}`

| Product Type | Example |
|---|---|
| Template pack | "SAP Project Kickoff Pack — 7 Ready-to-Use Consultant Templates" |
| Script | "CSV Cleaner Pro — Fix Messy Spreadsheets in 30 Seconds" |
| Cheatsheet | "SAP FICO Cheatsheet — Quick Reference for T-Codes, Tables & Flow" |
| Prompt pack | "Consultant AI Prompts — 20 ChatGPT Prompts for Freelance Proposals" |
| Guide | "Excel → Python Guide — Automate Your Spreadsheet Work in a Weekend" |

### DESCRIPTION Formula (5-part structure)

**Part 1 — The Pain (1-2 sentences)**
Open with the exact pain. Be specific. Name the time wasted or frustration.
> "Every SAP project starts the same way — you open a blank document and spend the first two hours rebuilding the same status template you've made 20 times before."

**Part 2 — What's Inside (2-3 sentences)**
List the actual files or contents. Be concrete.
> "This pack includes 7 ready-to-use templates: project kickoff agenda, weekly status report, stakeholder register, issue log, change request form, go-live checklist, and project closure summary."

**Part 3 — Who It's For (1-2 sentences)**
Name the exact buyer.
> "Built for freelance SAP consultants and project managers who want to start every engagement with professional, client-ready documents."

**Part 4 — What They'll Do (1-2 sentences)**
Future-state benefit after buying.
> "Open a new project, fill in your client name, and have a complete documentation set ready in 10 minutes."

**Part 5 — CTA (1 sentence)**
Standard close:
> "Instant download. No subscription. Use it on your next project today."

### TAG Strategy
Include: product type + niche + specific keywords + buyer role

Examples:
- SAP template pack: `sap, erp, consulting, template pack, project management, s4hana, kickoff`
- Python script: `python, csv, data cleaning, automation, script, spreadsheet, pandas`
- Prompt pack: `prompts, chatgpt, claude, consulting, freelance, proposals, ai`

## Pricing Reference

| Decision Factors | Price |
|---|---|
| Single file, hobbyist use | $5 |
| Single file, professional use | $9 |
| Multi-file or 1+ hr saved | $15 |
| Professional template pack (3+ files) | $25 |
| Comprehensive toolkit (5+ files, expert domain) | $39 |
| Premium pack, clear consultant ROI | $49 |

Professional niche bonus: +$10 if buyer is consultant/analyst.

## Thumbnail Prompt Templates

### Generic Template
"Flat design product cover, [topic keyword], [primary color] and white, minimal icons, clean typography, digital download badge. Text: '[short product name]'"

### By Niche
| Niche | Color Scheme | Icon Style |
|---|---|---|
| SAP/ERP | Navy and gold | Document/briefcase icons |
| Python/Data | Dark green and white | Terminal/code icons |
| Freelance | Purple and white | Calendar/contract icons |
| Excel | Green and dark gray | Spreadsheet/chart icons |
| AI Prompts | Blue gradient | Chat bubble icons |

### Tool Recommendations
- Canva (free): use "Digital Product" template, 1280×720px
- Leonardo.ai (free tier): use the prompt above
- Remove.bg: clean up any background

## Preview File Strategy
The preview (`dist/preview_{slug}.md`) shows first 20% of content:
- For scripts: show the README + first 20 lines of code (with comments)
- For prompt packs: show first 3-4 prompts with full content
- For templates: show the structure/outline with placeholder data
- For guides: show the table of contents + first full section
