# Publisher Agent Reference — Gumroad API, Publish Checklist, Post-Launch

## Gumroad API Reference

Base URL: `https://api.gumroad.com/v2`
Auth: `Authorization: Bearer {GUMROAD_ACCESS_TOKEN}`

### Endpoints Used

| Method | Endpoint | Purpose |
|--------|----------|---------|
| POST | /products | Create product (returns product id) |
| PUT | /products/{id}/files | Upload ZIP file |
| PUT | /products/{id} | Update product (set published: true) |
| GET | /products | List all products |

### Create Product Payload
```
name         = listing title
description  = listing description
price        = cents (e.g. 1500 for $15)
published    = false (create as draft first)
tags[]       = tag1, tag2 (repeated for each tag)
```

### File Upload
```
PUT /products/{id}/files
Content-Type: multipart/form-data
Body: file={zip binary}
```

### Publish
```
PUT /products/{id}
Body: published=true
```

## Pre-Flight Checklist
Before calling publish_gumroad.py:
- [ ] `products/{slug}/dist/{slug}_v1.zip` exists and is > 0 bytes
- [ ] `products/{slug}/listing.md` has all 5 sections: TITLE, DESCRIPTION, PRICE, TAGS, SUMMARY
- [ ] PRICE is an integer in cents (not "$15" — must be "1500")
- [ ] DESCRIPTION is 150-300 words
- [ ] `.env` has `GUMROAD_ACCESS_TOKEN` (not the placeholder)
- [ ] ZIP is under 250MB

## Post-Publish Verification
After publish_gumroad.py runs:
1. Confirm `products/{slug}/published.json` exists and contains `product_url`
2. Visit the `product_url` in a browser (or share with operator)
3. Verify: title, price, description, and download button are visible
4. Log the launch: `python scripts/log_sale.py live {slug} 0`

## Error Codes

| Code | Cause | Fix |
|------|-------|-----|
| 401 | Token invalid/expired | Update GUMROAD_ACCESS_TOKEN in .env |
| 422 | Missing required field | Check listing.md — all 5 sections present? |
| 413 | ZIP > 250MB | Remove large files from src/ |
| 404 | Product ID not found | Product may have been deleted manually on Gumroad |
| ConnectionError | No internet or Gumroad down | Check VPS connectivity |

Do not auto-retry. Report error to operator with fix steps.

## Post-Launch Promotion (Manual — by Operator)

### Day 1 (within 2 hours of going live)
1. Post in 1 relevant subreddit with value first, product second
   - r/sap, r/consulting, r/freelance, r/learnpython, r/excel
   - Title: Answer a question, mention the product at the end
   - Never "check out my product" — lead with value

2. Post in relevant Facebook groups (if member)

3. Post on LinkedIn (if active) — frame as "I built this for myself, sharing it"

### Week 1
- Reply to related Reddit questions linking to your product as a resource
- Share in relevant Discord servers (no-code, freelance, Python)

### Ongoing
- Each new product cross-promotes the others
- Bundle offer once you have 5+ products

## Revenue Logging

| Event | Command | When |
|-------|---------|------|
| Product goes live | `python scripts/log_sale.py live {slug} 0` | Right after publish |
| Sale received | `python scripts/log_sale.py sale {slug} {amount}` | When Gumroad notifies |
| Refund issued | `python scripts/log_sale.py refund {slug} {amount}` | When refund processed |

Gumroad sends email notifications for sales. Log them manually via `/log-sale`.
