# Product Tracker — Live Catalog & Revenue Goals

## Revenue Goals

| Milestone | Target | Status |
|-----------|--------|--------|
| First sale | $1 | ⏳ |
| Week 1 | $1+ | ⏳ |
| Month 1 | $100 | ⏳ |
| Month 2 | $300 | ⏳ |
| Month 3 | $500/mo | ⏳ |

## Live Products
*(updated by /log-sale live command)*

| # | Slug | Title | Price | Date Live | Sales | Revenue |
|---|------|-------|-------|-----------|-------|---------|
| — | — | — | — | — | — | — |

## Product Pipeline

| Stage | Slug | Type | Price | Next Action |
|-------|------|------|-------|-------------|
| Idea | — | — | — | /ideate |

## Standard Product Library (Build Queue)

| Priority | ID | Slug | Product | Type | Price | Est Hours | Status |
|----------|----|------|---------|------|-------|-----------|--------|
| ⭐⭐⭐ | P04 | upwork-proposal-templates | Upwork Proposal Templates (5 niches) | Template | $15 | 2 | 🔜 Build |
| ⭐⭐⭐ | P05 | sap-fico-cheatsheet | SAP FICO Cheatsheet | Cheatsheet | $9 | 2 | 🔜 Build |
| ⭐⭐ | P01 | sap-kickoff-template-pack | SAP Project Kickoff Template Pack | Template | $39 | 4 | Queued |
| ⭐⭐ | P02 | python-csv-cleaner | Python CSV Cleaner CLI | Script | $15 | 2 | Queued |
| ⭐⭐ | P03 | claude-prompts-for-consultants | Claude Prompts for Consultants | Prompt Pack | $19 | 3 | Queued |
| ⭐ | P06 | python-for-erp-consultants | Python for ERP Consultants — 30 Scripts | Script Pack | $49 | 6 | Queued |
| ⭐ | P07 | n8n-workflow-templates | n8n Workflow Templates (10 flows) | JSON Template | $25 | 3 | Queued |
| ⭐ | P08 | excel-to-python-guide | Excel → Python Migration Guide | Guide | $15 | 3 | Queued |

## Revenue Projection (Products Approach)

If all 8 standard products are live with 2 sales/month each:

| Product | Price | Sales/Mo | Revenue/Mo |
|---------|-------|----------|------------|
| P04 Upwork Templates | $15 | 4 | $60 |
| P05 SAP FICO Cheatsheet | $9 | 6 | $54 |
| P01 SAP Kickoff Pack | $39 | 3 | $117 |
| P02 CSV Cleaner | $15 | 4 | $60 |
| P03 Consultant Prompts | $19 | 3 | $57 |
| P06 Python ERP | $49 | 2 | $98 |
| P07 n8n Templates | $25 | 2 | $50 |
| P08 Excel→Python | $15 | 3 | $45 |
| **Total** | | **27** | **$541** |

Month 3 target of $500/month is achievable with 8 products live.

## Weekly Cadence
- **Monday:** /scan + /ideate (pick week's product)
- **Tuesday–Wednesday:** /validate + /build-product
- **Thursday:** /package + /publish
- **Friday:** /show-stats + plan next week
