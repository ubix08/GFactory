# Gumroad Factory — Project Instructions

## Mission
Build and publish one digital product per day on Gumroad.
Target: $1 first week → $500/month by month 3.

## Product Philosophy
- One sharp pain. One specific person. One afternoon to build.
- Deliverable must be a FILE (not a service, not a SaaS).
- "5-dollar skip test": would a busy professional pay $5 to skip building this?

## Operator Skills
- Strong: ERP/SAP consulting, business process, Python scripting, systems design
- Moderate: TypeScript, markdown, CLI tools
- Avoid: frontend UI, mobile apps, anything requiring ongoing maintenance

## Directory Structure
```
ideas/          → raw and scored ideas
products/       → one folder per product slug
  {slug}/
    src/        → source files (built product)
    dist/       → ZIP + preview
    listing.md  → Gumroad copy
    published.json → live product metadata
sales/          → revenue tracking
scripts/        → Python automation scripts
.opencode/      → agents, commands, context
```

## Queue Files
- `ideas/raw_signals.json`       → raw pain signals from trend_scan.py
- `ideas/scored_ideas.json`      → scored + qualified ideas
- `ideas/rejected_ideas.json`    → rejected ideas (log only)
- `ideas/validated/{slug}.json`  → per-idea research by @researcher
- `sales/stats.json`             → all sale events
- `sales/tracker.md`             → revenue dashboard

## Tool Selection by Product Type
| Type         | Format                                               |
|--------------|------------------------------------------------------|
| script       | Python, argparse CLI, README, requirements.txt       |
| prompt_pack  | .md file, 10-20 prompts, organized by use case       |
| template     | .xlsx or .md, structured, fill-in-the-blank format   |
| cheatsheet   | single .md page, table-heavy, print-ready structure  |
| guide        | multi-section .md, 800-2000 words, actionable steps  |
| micro_tool   | Python CLI + README + example input/output           |

## Pricing Tiers
| Price | Use Case                                              |
|-------|-------------------------------------------------------|
| $5    | impulse buy, single-use utility                       |
| $9    | low-friction professional tool                        |
| $15   | solid value, 30min+ time saved                        |
| $25   | professional template pack, ERP/consulting niche      |
| $39   | comprehensive toolkit, multiple files                 |
| $49   | premium pack, clear ROI for consultants               |

## Non-Negotiables
- Never build products requiring a paid API key to USE
- Never promise "updated regularly" unless automated
- Always include a README in every ZIP
- Always include a preview file (first 20% of content)
- Gumroad listing description must be 150-300 words
