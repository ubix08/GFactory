# Gumroad Factory

> AI-augmented digital product factory. One product per day. $500/month target.

## Quick Start

```bash
# 1. Copy and fill environment
cp .env.example .env
nano .env   # add GUMROAD_ACCESS_TOKEN and BRAVE_API_KEY

# 2. Run VPS setup (once)
bash scripts/setup-vps.sh

# 3. Install cron jobs
bash scripts/setup-cron.sh

# 4. Open OpenCode
opencode

# 5. Start first product
/ideate
```

## Pipeline

```
/ideate → /validate <slug> → /build-product <slug> → /package <slug> → /publish <slug>
```

Or run the full pipeline in one command:
```
/full-pipeline <slug>
```

## Architecture

| Layer | What | LLM Cost |
|-------|------|----------|
| Layer 1 — Python Scripts | Trend scanning, scoring, packaging, publishing | $0 |
| Layer 2 — OpenCode Agents | Ideation, research, building, copy-writing | Low–moderate |
| Layer 3 — Context Docs | Agent reference knowledge | Read-only |

## Agents

| Agent | Model | Role |
|-------|-------|------|
| @agent-0-scout | Haiku | Trend discovery |
| @agent-1-ideator | Haiku | Idea generation |
| @agent-2-researcher | Sonnet | Demand validation |
| @agent-3-builder | Sonnet | Product creation |
| @agent-4-packager | Sonnet | ZIP + listing copy |
| @agent-5-publisher | Sonnet | Gumroad publish |

## Standard Product Library (Start Here)

| ID | Product | Price | Build Hours |
|----|---------|-------|-------------|
| P04 | Upwork Proposal Templates (5 niches) | $15 | 2 |
| P05 | SAP FICO Cheatsheet | $9 | 2 |
| P01 | SAP Project Kickoff Template Pack | $39 | 4 |
| P02 | Python CSV Cleaner CLI | $15 | 2 |
| P03 | Claude Prompts for Consultants | $19 | 3 |

**Recommended first product:** `upwork-proposal-templates` (P04) — 2 hours, zero dependencies, real demand.

## Directory Structure

```
gumroad-factory/
├── ideas/              # pain signals + scored ideas
├── products/           # one folder per product slug
├── sales/              # revenue tracker
├── logs/               # cron output
├── scripts/            # Python automation
└── .opencode/
    ├── agents/         # agent definitions
    ├── commands/       # slash commands
    └── context/        # agent reference knowledge
```
