#!/usr/bin/env python3
"""
log_sale.py — Revenue Tracker
Records sale events and regenerates sales/tracker.md dashboard.
Usage: python scripts/log_sale.py <event> <slug> <amount>
Events: live | sale | refund
"""

import json
import sys
from datetime import datetime, timezone
from pathlib import Path

try:
    from rich.console import Console
    from rich.table import Table
except ImportError:
    print("Missing: pip install rich")
    sys.exit(1)

console = Console()

BASE_DIR = Path(__file__).parent.parent
SALES_DIR = BASE_DIR / "sales"
STATS_FILE = SALES_DIR / "stats.json"
TRACKER_FILE = SALES_DIR / "tracker.md"
PRODUCTS_DIR = BASE_DIR / "products"

VALID_EVENTS = ("live", "sale", "refund")


def load_stats() -> list:
    if STATS_FILE.exists():
        return json.loads(STATS_FILE.read_text())
    return []


def save_stats(stats: list) -> None:
    STATS_FILE.write_text(json.dumps(stats, indent=2))


def get_product_title(slug: str) -> str:
    listing = PRODUCTS_DIR / slug / "listing.md"
    if listing.exists():
        for line in listing.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#"):
                return line[:60]
    return slug.replace("-", " ").title()


def get_product_price(slug: str) -> float:
    pub = PRODUCTS_DIR / slug / "published.json"
    if pub.exists():
        data = json.loads(pub.read_text())
        return data.get("price_cents", 0) / 100
    return 0.0


def regenerate_tracker(stats: list) -> None:
    # Aggregate per slug
    products: dict = {}
    for event in stats:
        slug = event["slug"]
        if slug not in products:
            products[slug] = {
                "slug": slug,
                "title": get_product_title(slug),
                "price": get_product_price(slug),
                "sales": 0,
                "revenue": 0.0,
                "live": False,
            }
        if event["event"] == "live":
            products[slug]["live"] = True
        elif event["event"] == "sale":
            products[slug]["sales"] += 1
            products[slug]["revenue"] += float(event["amount"])
        elif event["event"] == "refund":
            products[slug]["sales"] = max(0, products[slug]["sales"] - 1)
            products[slug]["revenue"] = max(0, products[slug]["revenue"] - float(event["amount"]))

    total_revenue = sum(p["revenue"] for p in products.values())
    products_live = sum(1 for p in products.values() if p["live"])
    goal = 500.0
    goal_pct = round(total_revenue / goal * 100, 1)

    # Recent 10 sales
    recent_sales = [e for e in reversed(stats) if e["event"] == "sale"][:10]

    # Build markdown
    lines = [
        "# Gumroad Factory — Revenue Tracker",
        "",
        "## Totals",
        f"- Products live: {products_live}",
        f"- Total revenue: ${total_revenue:.2f}",
        f"- Goal ($500/mo): {goal_pct}%",
        "",
        "## Products Live",
        "",
        "| Slug | Title | Price | Sales | Revenue |",
        "|------|-------|-------|-------|---------|",
    ]

    for p in sorted(products.values(), key=lambda x: x["revenue"], reverse=True):
        status = "✓" if p["live"] else "—"
        lines.append(f"| {p['slug']} | {p['title']} | ${p['price']:.2f} | {p['sales']} | ${p['revenue']:.2f} |")

    if not products:
        lines.append("| — | — | — | — | — |")

    lines += ["", "## Recent Sales", "", "| Date | Slug | Amount |", "|------|------|--------|"]

    for sale in recent_sales:
        date = sale["timestamp"][:10]
        lines.append(f"| {date} | {sale['slug']} | ${float(sale['amount']):.2f} |")

    if not recent_sales:
        lines.append("| — | — | — |")

    TRACKER_FILE.write_text("\n".join(lines) + "\n")


def main() -> None:
    if len(sys.argv) < 4:
        console.print("[red]Usage: python scripts/log_sale.py <event> <slug> <amount>[/red]")
        console.print("Events: live | sale | refund")
        sys.exit(1)

    event = sys.argv[1].strip().lower()
    slug = sys.argv[2].strip()
    amount_str = sys.argv[3].strip().lstrip("$")

    if event not in VALID_EVENTS:
        console.print(f"[red]Invalid event '{event}'. Use: {', '.join(VALID_EVENTS)}[/red]")
        sys.exit(1)

    try:
        amount = float(amount_str)
    except ValueError:
        console.print(f"[red]Invalid amount: {amount_str}[/red]")
        sys.exit(1)

    SALES_DIR.mkdir(parents=True, exist_ok=True)
    stats = load_stats()
    entry = {
        "event": event,
        "slug": slug,
        "amount": amount,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "notes": "",
    }
    stats.append(entry)
    save_stats(stats)
    regenerate_tracker(stats)

    icon = {"live": "🚀", "sale": "💰", "refund": "↩️"}.get(event, "•")
    console.print(f"{icon} Logged: [{event}] {slug} ${amount:.2f}")
    console.print("  tracker.md updated.")


if __name__ == "__main__":
    main()
