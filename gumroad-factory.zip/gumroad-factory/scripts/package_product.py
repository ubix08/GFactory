#!/usr/bin/env python3
"""
package_product.py — Product Packager
Packages a built product into a distributable ZIP with preview.
Usage: python scripts/package_product.py <slug>
"""

import json
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path

try:
    from rich.console import Console
except ImportError:
    print("Missing dependencies. Run: pip install rich")
    sys.exit(1)

console = Console()

BASE_DIR = Path(__file__).parent.parent


def get_preview_content(src_dir: Path, slug: str) -> str:
    """Extract first 20% of main content file for preview."""
    # Priority order for main file
    candidates = list(src_dir.glob("*.md")) + list(src_dir.glob("*.py")) + list(src_dir.glob("*.txt"))
    readme = src_dir / "README.md"
    candidates = [f for f in candidates if f != readme]

    if not candidates:
        return f"# Preview — {slug}\n\nSee the full product in the ZIP download."

    main_file = candidates[0]
    content = main_file.read_text(encoding="utf-8", errors="replace")
    cutoff = max(200, len(content) // 5)
    preview = content[:cutoff]
    return f"# Preview — {slug}\n\n*This is the first 20% of the product. Full content in the ZIP.*\n\n---\n\n{preview}\n\n---\n\n*[Full content continues in the download...]*"


def write_readme_if_missing(src_dir: Path, slug: str, listing_path: Path) -> None:
    readme = src_dir / "README.md"
    if readme.exists():
        return

    # Try to pull title from listing.md
    title = slug.replace("-", " ").title()
    if listing_path.exists():
        for line in listing_path.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#"):
                title = line
                break

    readme.write_text(
        f"# {title}\n\n"
        "## What's Included\n"
        "See the files in this ZIP for all product content.\n\n"
        "## How to Use\n"
        "1. Unzip the archive\n"
        "2. Open the main file\n"
        "3. Follow the instructions inside\n\n"
        "## Support\n"
        "Questions? Contact via Gumroad.\n"
    )
    console.print(f"  [yellow]README.md created automatically (fill in details)[/yellow]")


def main() -> None:
    if len(sys.argv) < 2:
        console.print("[red]Usage: python scripts/package_product.py <slug>[/red]")
        sys.exit(1)

    slug = sys.argv[1].strip()
    product_dir = BASE_DIR / "products" / slug
    src_dir = product_dir / "src"
    dist_dir = product_dir / "dist"
    listing_path = product_dir / "listing.md"

    if not product_dir.exists():
        console.print(f"[red]Product directory not found: products/{slug}[/red]")
        sys.exit(1)

    if not src_dir.exists() or not any(src_dir.iterdir()):
        console.print(f"[red]products/{slug}/src/ is empty or missing. Build the product first.[/red]")
        sys.exit(1)

    dist_dir.mkdir(parents=True, exist_ok=True)

    # Ensure README exists
    write_readme_if_missing(src_dir, slug, listing_path)

    # Generate preview
    preview_content = get_preview_content(src_dir, slug)
    preview_path = dist_dir / f"preview_{slug}.md"
    preview_path.write_text(preview_content, encoding="utf-8")
    console.print(f"  Preview generated: {preview_path.name}")

    # Build ZIP
    zip_path = dist_dir / f"{slug}_v1.zip"
    files_included = []
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in sorted(src_dir.rglob("*")):
            if f.is_file():
                arcname = f.relative_to(src_dir)
                zf.write(f, arcname)
                files_included.append(str(arcname))

    zip_size_kb = round(zip_path.stat().st_size / 1024, 1)
    console.print(f"  ZIP created: {zip_path.name} ({zip_size_kb} KB, {len(files_included)} files)")

    # Write manifest
    manifest = {
        "slug": slug,
        "version": "1.0",
        "files_included": files_included,
        "zip_path": str(zip_path.relative_to(BASE_DIR)),
        "preview_path": str(preview_path.relative_to(BASE_DIR)),
        "file_size_kb": zip_size_kb,
        "packaged_at": datetime.now(timezone.utc).isoformat(),
    }
    manifest_path = dist_dir / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2))

    console.print(f"\n[bold green]✓ Packaging complete for {slug}[/bold green]")
    console.print(f"  ZIP:      products/{slug}/dist/{slug}_v1.zip")
    console.print(f"  Preview:  products/{slug}/dist/preview_{slug}.md")
    console.print(f"  Manifest: products/{slug}/dist/manifest.json")

    if not listing_path.exists():
        console.print(f"\n[yellow]⚠ listing.md not found. Run @agent-4-packager to generate listing copy.[/yellow]")


if __name__ == "__main__":
    main()
