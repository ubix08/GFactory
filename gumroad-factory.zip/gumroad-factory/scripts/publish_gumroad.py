#!/usr/bin/env python3
"""
publish_gumroad.py — Gumroad Publisher
Reads products/{slug}/listing.md + dist ZIP, creates & publishes product via Gumroad API v2.
Usage: python scripts/publish_gumroad.py <slug>
"""

import json
import os
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

try:
    import requests
    from dotenv import load_dotenv
    from rich.console import Console
except ImportError:
    print("Missing dependencies. Run: pip install requests python-dotenv rich")
    sys.exit(1)

console = Console()

BASE_DIR = Path(__file__).parent.parent
load_dotenv(BASE_DIR / ".env")

GUMROAD_API = "https://api.gumroad.com/v2"


def get_token() -> str:
    token = os.getenv("GUMROAD_ACCESS_TOKEN", "")
    if not token or token == "your_gumroad_token_here":
        console.print("[red]GUMROAD_ACCESS_TOKEN not set. Add it to your .env file.[/red]")
        sys.exit(1)
    return token


def parse_listing(listing_path: Path) -> dict:
    """Parse listing.md into structured fields."""
    text = listing_path.read_text(encoding="utf-8")
    sections = {}
    current = None
    lines = []

    for line in text.splitlines():
        if line.startswith("# "):
            if current and lines:
                sections[current] = "\n".join(lines).strip()
            current = line[2:].strip().upper()
            lines = []
        else:
            lines.append(line)

    if current and lines:
        sections[current] = "\n".join(lines).strip()

    required = ["TITLE", "DESCRIPTION", "PRICE", "TAGS", "SUMMARY"]
    missing = [r for r in required if r not in sections]
    if missing:
        console.print(f"[red]listing.md is missing sections: {', '.join(missing)}[/red]")
        console.print("Required sections: # TITLE, # DESCRIPTION, # PRICE, # TAGS, # SUMMARY")
        sys.exit(1)

    try:
        price_cents = int(re.sub(r"[^\d]", "", sections["PRICE"]))
    except ValueError:
        console.print(f"[red]Invalid PRICE in listing.md: {sections['PRICE']}[/red]")
        sys.exit(1)

    return {
        "title": sections["TITLE"],
        "description": sections["DESCRIPTION"],
        "price_cents": price_cents,
        "tags": [t.strip() for t in sections["TAGS"].split(",") if t.strip()],
        "summary": sections["SUMMARY"],
    }


def create_product(token: str, listing: dict) -> str:
    """Create product on Gumroad, return product ID."""
    payload = {
        "name": listing["title"],
        "description": listing["description"],
        "price": listing["price_cents"],
        "url": listing["summary"][:100],
        "published": "false",
    }
    if listing["tags"]:
        payload["tags[]"] = listing["tags"]

    resp = requests.post(
        f"{GUMROAD_API}/products",
        headers={"Authorization": f"Bearer {token}"},
        data=payload,
        timeout=30,
    )

    if resp.status_code == 401:
        console.print("[red]401 Unauthorized — GUMROAD_ACCESS_TOKEN is invalid or expired.[/red]")
        sys.exit(1)
    if resp.status_code == 422:
        console.print(f"[red]422 Unprocessable — {resp.text}[/red]")
        sys.exit(1)
    if not resp.ok:
        console.print(f"[red]Gumroad API error {resp.status_code}: {resp.text}[/red]")
        sys.exit(1)

    data = resp.json()
    if not data.get("success"):
        console.print(f"[red]Gumroad API returned failure: {data}[/red]")
        sys.exit(1)

    return data["product"]["id"]


def upload_file(token: str, product_id: str, zip_path: Path) -> None:
    """Upload ZIP as product attachment."""
    zip_size_mb = zip_path.stat().st_size / (1024 * 1024)
    if zip_size_mb > 250:
        console.print(f"[red]ZIP is {zip_size_mb:.1f} MB — Gumroad limit is 250 MB.[/red]")
        sys.exit(1)

    with zip_path.open("rb") as f:
        resp = requests.put(
            f"{GUMROAD_API}/products/{product_id}/files",
            headers={"Authorization": f"Bearer {token}"},
            files={"file": (zip_path.name, f, "application/zip")},
            timeout=120,
        )

    if not resp.ok:
        console.print(f"[red]File upload error {resp.status_code}: {resp.text}[/red]")
        sys.exit(1)
    console.print(f"  File uploaded: {zip_path.name}")


def publish_product(token: str, product_id: str) -> str:
    """Set product to published, return product URL."""
    resp = requests.put(
        f"{GUMROAD_API}/products/{product_id}",
        headers={"Authorization": f"Bearer {token}"},
        data={"published": "true"},
        timeout=30,
    )
    if not resp.ok:
        console.print(f"[red]Publish error {resp.status_code}: {resp.text}[/red]")
        sys.exit(1)

    data = resp.json()
    return data["product"].get("short_url") or f"https://gumroad.com/l/{product_id}"


def main() -> None:
    if len(sys.argv) < 2:
        console.print("[red]Usage: python scripts/publish_gumroad.py <slug>[/red]")
        sys.exit(1)

    slug = sys.argv[1].strip()
    product_dir = BASE_DIR / "products" / slug
    listing_path = product_dir / "listing.md"
    zip_path = product_dir / "dist" / f"{slug}_v1.zip"

    if not listing_path.exists():
        console.print(f"[red]listing.md not found for {slug}. Run @agent-4-packager first.[/red]")
        sys.exit(1)

    if not zip_path.exists():
        console.print(f"[red]ZIP not found: {zip_path}. Run package_product.py first.[/red]")
        sys.exit(1)

    token = get_token()
    listing = parse_listing(listing_path)

    console.print(f"\n[bold]Publishing:[/bold] {listing['title']} @ ${listing['price_cents'] / 100:.2f}")

    console.print("  Creating product on Gumroad...")
    product_id = create_product(token, listing)
    console.print(f"  Product ID: {product_id}")

    console.print("  Uploading ZIP...")
    upload_file(token, product_id, zip_path)

    console.print("  Publishing...")
    product_url = publish_product(token, product_id)

    # Write published.json
    published = {
        "gumroad_id": product_id,
        "product_url": product_url,
        "title": listing["title"],
        "price_cents": listing["price_cents"],
        "published_at": datetime.now(timezone.utc).isoformat(),
        "status": "live",
    }
    published_path = product_dir / "published.json"
    published_path.write_text(json.dumps(published, indent=2))

    console.print(f"\n[bold green]✓ Published successfully![/bold green]")
    console.print(f"  URL: {product_url}")
    console.print(f"  Run: python scripts/log_sale.py live {slug} 0")


if __name__ == "__main__":
    main()
