#!/usr/bin/env python3
"""
run_factory.py — Master Pipeline Orchestrator
CLI frontend for running pipeline stages.
Usage: python scripts/run_factory.py <command> [args]
"""

import json
import subprocess
import sys
from pathlib import Path

try:
    from rich.console import Console
    from rich.table import Table
except ImportError:
    print("Missing: pip install rich")
    sys.exit(1)

console = Console()
BASE_DIR = Path(__file__).parent.parent
SCRIPTS = BASE_DIR / "scripts"

HELP = """
Gumroad Factory — Pipeline CLI

Commands:
  scan              Run trend_scan.py — collect pain signals
  score             Run score_ideas.py — score and classify signals
  show              Display top 5 scored ACCEPT ideas
  package <slug>    Run package_product.py for a product
  publish <slug>    Run publish_gumroad.py for a product
  stats             Show sales/tracker.md summary
  full              Run scan + score + show sequentially

Examples:
  python scripts/run_factory.py full
  python scripts/run_factory.py package upwork-proposal-templates
  python scripts/run_factory.py publish upwork-proposal-templates
  python scripts/run_factory.py stats
"""


def run_script(script_name: str, *args) -> int:
    cmd = [sys.executable, str(SCRIPTS / script_name)] + list(args)
    result = subprocess.run(cmd, cwd=BASE_DIR)
    return result.returncode


def cmd_show() -> None:
    scored_file = BASE_DIR / "ideas" / "scored_ideas.json"
    if not scored_file.exists():
        console.print("[yellow]No scored ideas yet. Run: python scripts/run_factory.py score[/yellow]")
        return

    ideas = json.loads(scored_file.read_text())
    accepts = [i for i in ideas if i["decision"] == "ACCEPT"]
    accepts.sort(key=lambda x: x["scores"]["total"], reverse=True)

    if not accepts:
        console.print("[yellow]No ACCEPT-tier ideas yet.[/yellow]")
        return

    table = Table(title=f"Top Ideas ({len(accepts)} ACCEPT total)")
    table.add_column("#", style="dim")
    table.add_column("Concept", style="white", max_width=45)
    table.add_column("Type", style="cyan")
    table.add_column("Score", justify="right", style="green")
    table.add_column("Price", justify="right", style="yellow")
    table.add_column("Hrs", justify="right")
    table.add_column("Niche", style="magenta", max_width=22)

    for i, idea in enumerate(accepts[:5], 1):
        table.add_row(
            str(i),
            idea["title"][:45],
            idea["product_type"],
            str(idea["scores"]["total"]),
            f"${idea['suggested_price']}",
            str(idea["estimated_build_hours"]),
            idea["niche"],
        )
    console.print(table)
    console.print("\nReply with number or slug to proceed with /ideate → /validate → /build-product")


def cmd_stats() -> None:
    tracker = BASE_DIR / "sales" / "tracker.md"
    if not tracker.exists():
        console.print("[yellow]No sales data yet.[/yellow]")
        return
    console.print(tracker.read_text())


def main() -> None:
    if len(sys.argv) < 2:
        console.print(HELP)
        sys.exit(0)

    cmd = sys.argv[1].lower()
    args = sys.argv[2:]

    if cmd == "scan":
        sys.exit(run_script("trend_scan.py"))
    elif cmd == "score":
        sys.exit(run_script("score_ideas.py"))
    elif cmd == "show":
        cmd_show()
    elif cmd == "package":
        if not args:
            console.print("[red]Usage: package <slug>[/red]")
            sys.exit(1)
        sys.exit(run_script("package_product.py", args[0]))
    elif cmd == "publish":
        if not args:
            console.print("[red]Usage: publish <slug>[/red]")
            sys.exit(1)
        sys.exit(run_script("publish_gumroad.py", args[0]))
    elif cmd == "stats":
        cmd_stats()
    elif cmd == "full":
        console.print("[bold cyan]Running full pipeline: scan → score → show[/bold cyan]\n")
        rc = run_script("trend_scan.py")
        if rc != 0:
            sys.exit(rc)
        rc = run_script("score_ideas.py")
        if rc != 0:
            sys.exit(rc)
        cmd_show()
    else:
        console.print(f"[red]Unknown command: {cmd}[/red]")
        console.print(HELP)
        sys.exit(1)


if __name__ == "__main__":
    main()
