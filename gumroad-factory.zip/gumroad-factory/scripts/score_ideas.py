#!/usr/bin/env python3
"""
score_ideas.py — Deterministic Idea Scorer
Reads ideas/raw_signals.json, applies scoring rules, writes:
  ideas/scored_ideas.json   → ACCEPT + HOLD
  ideas/rejected_ideas.json → REJECT
"""

import json
import sys
from datetime import datetime, timezone
from pathlib import Path

try:
    from rich.console import Console
    from rich.table import Table
except ImportError:
    print("Missing dependencies. Run: pip install rich")
    sys.exit(1)

console = Console()

BASE_DIR = Path(__file__).parent.parent
IDEAS_DIR = BASE_DIR / "ideas"
RAW_FILE = IDEAS_DIR / "raw_signals.json"
SCORED_FILE = IDEAS_DIR / "scored_ideas.json"
REJECTED_FILE = IDEAS_DIR / "rejected_ideas.json"

# Scoring keyword maps
PAIN_HIGH = ["every day", "hours", "hate this", "sick of", "tired of", "frustrated", "manually", "repetitive", "annoying"]
PAIN_MED = ["how do i", "wish there was", "tedious", "no good solution", "does anyone"]

BUILDABLE_HIGH = ["script", "template", "cheatsheet", "prompt", "csv", "excel", "python", "cli"]
BUILDABLE_LOW = ["app", "platform", "saas", "database", "mobile", "real-time", "api"]

MONEY_HIGH = ["consultant", "analyst", "developer", "professional", "freelance", "agency", "business"]
MONEY_MED = ["student", "beginner", "learning"]

FIT_HIGH = ["sap", "erp", "fico", "abap", "oracle", "s/4hana", "excel", "python", "csv", "automation",
            "consulting", "freelance", "upwork", "data", "template", "cheatsheet", "proposal"]

REJECT_OVERRIDES = [
    ("saas", "Requires SaaS subscription to deliver"),
    ("subscription", "Requires subscription model"),
    ("social following", "Requires audience/social following"),
    ("followers", "Requires followers"),
    ("maintain", "Ongoing maintenance implied"),
    ("update weekly", "Weekly update promise implied"),
    ("legal", "Legal/compliance product — liability risk"),
    ("compliance", "Compliance product — liability risk"),
]

PRODUCT_TYPE_MAP = {
    "script": ["script", "python", "cli", "tool", "automate", "csv", "json"],
    "prompt_pack": ["prompt", "chatgpt", "claude", "gpt", "ai assistant"],
    "template": ["template", "spreadsheet", "excel", "xlsx", "docx", "proposal", "contract"],
    "cheatsheet": ["cheatsheet", "cheat sheet", "quick reference", "reference card", "cheat"],
    "guide": ["guide", "tutorial", "how to", "walkthrough", "explained"],
    "micro_tool": ["tool", "utility", "helper", "converter", "parser"],
}

PRICE_TIERS = [5, 9, 15, 25, 39, 49]


def infer_product_type(text: str) -> str:
    text_lower = text.lower()
    for ptype, keywords in PRODUCT_TYPE_MAP.items():
        if any(kw in text_lower for kw in keywords):
            return ptype
    return "guide"


def infer_price(scores: dict, product_type: str, niche: str) -> int:
    hours = max(1, round((10 - scores["buildability"]) / 2))
    base = max(9, hours * 12)
    if any(w in niche.lower() for w in ["sap", "erp", "consulting", "analyst"]):
        base += 10
    # Round to nearest tier
    return min(PRICE_TIERS, key=lambda t: abs(t - base))


def infer_niche(text: str) -> str:
    text_lower = text.lower()
    if any(w in text_lower for w in ["sap", "erp", "fico", "abap", "s/4"]):
        return "ERP / SAP Consulting"
    if any(w in text_lower for w in ["upwork", "freelance", "proposal", "contract"]):
        return "Freelancers"
    if any(w in text_lower for w in ["excel", "spreadsheet"]):
        return "Excel Power Users"
    if any(w in text_lower for w in ["python", "csv", "data", "pandas"]):
        return "Python / Data Analysts"
    if any(w in text_lower for w in ["n8n", "zapier", "automation", "workflow"]):
        return "No-Code Automation"
    if any(w in text_lower for w in ["prompt", "ai", "chatgpt", "claude"]):
        return "AI Prompt Users"
    return "General Professional"


def score_signal(signal: dict) -> dict:
    text = (signal["title"] + " " + signal.get("body_snippet", "")).lower()

    # Pain score (0-10)
    pain = 5
    for kw in PAIN_HIGH:
        if kw in text:
            pain = min(10, pain + 2)
    for kw in PAIN_MED:
        if kw in text:
            pain = min(10, pain + 1)
    upvotes = signal.get("upvotes", 0)
    if upvotes > 100:
        pain = min(10, pain + 2)
    elif upvotes > 20:
        pain = min(10, pain + 1)

    # Buildability score (0-10)
    buildability = 6
    for kw in BUILDABLE_HIGH:
        if kw in text:
            buildability = min(10, buildability + 1)
    for kw in BUILDABLE_LOW:
        if kw in text:
            buildability = max(0, buildability - 3)

    # Monetizability score (0-10)
    monetizability = 5
    for kw in MONEY_HIGH:
        if kw in text:
            monetizability = min(10, monetizability + 2)
    for kw in MONEY_MED:
        if kw in text:
            monetizability = min(10, monetizability + 0.5)

    # Operator fit (0-10)
    fit = 3
    for kw in FIT_HIGH:
        if kw in text:
            fit = min(10, fit + 1.5)

    scores = {
        "pain": round(pain, 1),
        "buildability": round(buildability, 1),
        "monetizability": round(monetizability, 1),
        "operator_fit": round(min(10, fit), 1),
    }
    total = round(
        scores["pain"] * 0.35
        + scores["buildability"] * 0.30
        + scores["monetizability"] * 0.25
        + scores["operator_fit"] * 0.10,
        2,
    )
    scores["total"] = total

    # Decision
    decision = "REJECT"
    reject_reason = None
    for override_kw, reason in REJECT_OVERRIDES:
        if override_kw in text:
            reject_reason = reason
            break

    if not reject_reason:
        if total >= 7.0:
            decision = "ACCEPT"
        elif total >= 4.0:
            decision = "HOLD"
        else:
            decision = "REJECT"
            reject_reason = f"Score too low ({total})"

    product_type = infer_product_type(text)
    niche = infer_niche(text)
    suggested_price = infer_price(scores, product_type, niche)
    build_hours = round(max(1, (10 - scores["buildability"]) / 2), 1)

    return {
        "id": signal["id"] + "_scored",
        "signal_id": signal["id"],
        "title": signal["title"],
        "product_concept": signal["title"],
        "product_type": product_type,
        "niche": niche,
        "scores": scores,
        "decision": decision,
        "reject_reason": reject_reason,
        "suggested_price": suggested_price,
        "estimated_build_hours": build_hours,
        "scored_at": datetime.now(timezone.utc).isoformat(),
    }


def main() -> None:
    if not RAW_FILE.exists():
        console.print("[red]ideas/raw_signals.json not found. Run trend_scan.py first.[/red]")
        sys.exit(1)

    signals = json.loads(RAW_FILE.read_text())
    if not signals:
        console.print("[yellow]No signals to score. Run trend_scan.py first.[/yellow]")
        return

    # Load existing scored to avoid duplicates
    existing_scored = json.loads(SCORED_FILE.read_text()) if SCORED_FILE.exists() else []
    existing_rejected = json.loads(REJECTED_FILE.read_text()) if REJECTED_FILE.exists() else []
    scored_signal_ids = {s["signal_id"] for s in existing_scored + existing_rejected}

    new_scored, new_rejected = [], []
    for signal in signals:
        if signal["id"] in scored_signal_ids:
            continue
        result = score_signal(signal)
        if result["decision"] == "REJECT":
            new_rejected.append(result)
        else:
            new_scored.append(result)

    all_scored = existing_scored + new_scored
    all_rejected = existing_rejected + new_rejected

    SCORED_FILE.write_text(json.dumps(all_scored, indent=2))
    REJECTED_FILE.write_text(json.dumps(all_rejected, indent=2))

    accept_count = sum(1 for s in all_scored if s["decision"] == "ACCEPT")
    hold_count = sum(1 for s in all_scored if s["decision"] == "HOLD")

    console.print(f"\n[bold green]Scoring complete.[/bold green]")
    console.print(f"  ACCEPT: {accept_count}  |  HOLD: {hold_count}  |  REJECT: {len(all_rejected)}")

    accepts = [s for s in all_scored if s["decision"] == "ACCEPT"]
    accepts.sort(key=lambda x: x["scores"]["total"], reverse=True)

    table = Table(title="Top 5 ACCEPT Ideas")
    table.add_column("#", style="dim")
    table.add_column("Concept", style="white", max_width=45)
    table.add_column("Type", style="cyan")
    table.add_column("Score", justify="right", style="green")
    table.add_column("Price", justify="right", style="yellow")
    table.add_column("Hrs", justify="right")
    table.add_column("Niche", style="magenta", max_width=22)

    for i, s in enumerate(accepts[:5], 1):
        table.add_row(
            str(i),
            s["title"][:45],
            s["product_type"],
            str(s["scores"]["total"]),
            f"${s['suggested_price']}",
            str(s["estimated_build_hours"]),
            s["niche"],
        )
    console.print(table)


if __name__ == "__main__":
    main()
