#!/usr/bin/env bash
# setup-cron.sh — Install cron jobs for Gumroad Factory
# Run: bash scripts/setup-cron.sh

set -e
FACTORY_DIR="$(cd "$(dirname "$0")/.." && pwd)"
PYTHON="$(which python3)"
LOG_DIR="$FACTORY_DIR/logs"

mkdir -p "$LOG_DIR"

CRON_SCAN="0 9 * * 1-5 cd $FACTORY_DIR && $PYTHON scripts/trend_scan.py >> $LOG_DIR/scan.log 2>&1"
CRON_SCORE="0 9,17 * * * cd $FACTORY_DIR && $PYTHON scripts/score_ideas.py >> $LOG_DIR/score.log 2>&1"

echo "Installing cron jobs..."

# Remove old factory jobs, add new ones
(crontab -l 2>/dev/null | grep -v "gumroad-factory\|trend_scan\|score_ideas"; \
  echo "$CRON_SCAN"; echo "$CRON_SCORE") | crontab -

echo "Cron jobs installed:"
echo "  09:00 Mon-Fri → trend_scan.py"
echo "  09:00 + 17:00 daily → score_ideas.py"
echo ""
echo "Current crontab:"
crontab -l
