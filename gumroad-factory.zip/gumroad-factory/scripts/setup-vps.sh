#!/usr/bin/env bash
# setup-vps.sh — One-time VPS bootstrap for Gumroad Factory
# Run: bash scripts/setup-vps.sh
set -e

echo "=== Gumroad Factory — VPS Setup ==="

# System packages
echo "[1/5] Installing system packages..."
apt-get update -qq
apt-get install -y -qq python3 python3-pip curl git wget unzip

# Node.js (for MCP server)
echo "[2/5] Installing Node.js..."
if ! command -v node &>/dev/null; then
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt-get install -y -qq nodejs
fi
echo "  Node: $(node --version)"
echo "  npm:  $(npm --version)"

# Python packages
echo "[3/5] Installing Python packages..."
pip3 install --quiet --upgrade pip
pip3 install --quiet feedparser requests rich python-dotenv openpyxl pandas

echo "  Python packages installed."

# MCP Brave Search server (pre-fetch)
echo "[4/5] Pre-fetching MCP Brave Search server..."
npx -y @modelcontextprotocol/server-brave-search --version 2>/dev/null || true

# Project directories
echo "[5/5] Creating project directories..."
DIRS=(
    "ideas/validated"
    "products"
    "sales"
    "logs"
    "scripts"
    ".opencode/agents"
    ".opencode/commands"
    ".opencode/context/factory"
)
for dir in "${DIRS[@]}"; do
    mkdir -p "$dir"
done

# Initialize JSON files if missing
for f in ideas/raw_signals.json ideas/scored_ideas.json ideas/rejected_ideas.json ideas/seen_signals.json sales/stats.json; do
    [ -f "$f" ] || echo '[]' > "$f"
done

# .env from template
if [ ! -f ".env" ] && [ -f ".env.example" ]; then
    cp .env.example .env
    echo "  .env created from .env.example — fill in your tokens."
fi

echo ""
echo "=== Setup complete ==="
echo ""
echo "Next steps:"
echo "  1. nano .env  (add GUMROAD_ACCESS_TOKEN and BRAVE_API_KEY)"
echo "  2. bash scripts/setup-cron.sh"
echo "  3. opencode"
echo "  4. /ideate"
