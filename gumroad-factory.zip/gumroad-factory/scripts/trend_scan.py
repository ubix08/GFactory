#!/usr/bin/env python3
"""
trend_scan.py — Pain Signal Collector
Collects raw pain signals from Reddit RSS, Hacker News Algolia API, and Google Trends RSS.
Deduplicates via MD5 hash stored in ideas/seen_signals.json.
Output: ideas/raw_signals.json
"""

import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

try:
    import feedparser
    import requests
    from rich.console import Console
    from rich.table import Table
except ImportError:
    print("Missing dependencies. Run: pip install feedparser requests rich")
    sys.exit(1)

console = Console()

BASE_DIR = Path(__file__).parent.parent
IDEAS_DIR = BASE_DIR / "ideas"
RAW_SIGNALS_FILE = IDEAS_DIR / "raw_signals.json"
SEEN_SIGNALS_FILE = IDEAS_DIR / "seen_signals.json"

REDDIT_FEEDS = [
    "https://www.reddit.com/r/entrepreneur/new.rss",
    "https://www.reddit.com/r/digitalnomad/new.rss",
    "https://www.reddit.com/r/consulting/new.rss",
    "https://www.reddit.com/r/sap/new.rss",
    "https://www.reddit.com/r/excel/new.rss",
    "https://www.reddit.com/r/learnpython/new.rss",
    "https://www.reddit.com/r/freelance/new.rss",
    "https://www.reddit.com/r/Upwork/new.rss",
]

PAIN_KEYWORDS = [
    "how do i", "annoying", "wish there was", "does anyone",
    "hate this", "every day", "hours", "tedious", "automate",
    "template", "pain", "frustrated", "tired of", "sick of",
    "no good solution", "manually", "repetitive",
]

HN_SEARCH_TERMS = ["pain", "tedious", "automate", "template", "annoying", "wish"]

GTRENDS_FEEDS = [
    "https://trends.google.com/trends/trendingsearches/daily/rss?geo=US",
]

HEADERS = {"User-Agent": "GumroadFactoryBot/1.0 (research purposes)"}


def md5_id(title: str, url: str) -> str:
    return hashlib.md5(f"{title}{url}".encode()).hexdigest()


def load_seen() -> set:
    if SEEN_SIGNALS_FILE.exists():
        try:
            return set(json.loads(SEEN_SIGNALS_FILE.read_text()))
        except Exception:
            return set()
    return set()


def save_seen(seen: set) -> None:
    SEEN_SIGNALS_FILE.write_text(json.dumps(sorted(seen), indent=2))


def load_existing() -> list:
    if RAW_SIGNALS_FILE.exists():
        try:
            return json.loads(RAW_SIGNALS_FILE.read_text())
        except Exception:
            return []
    return []


def keywords_matched(text: str) -> list:
    text_lower = text.lower()
    return [kw for kw in PAIN_KEYWORDS if kw in text_lower]


def scan_reddit() -> list:
    signals = []
    console.print("[bold cyan]Scanning Reddit RSS feeds...[/bold cyan]")
    for feed_url in REDDIT_FEEDS:
        try:
            feed = feedparser.parse(feed_url)
            for entry in feed.entries[:20]:
                title = entry.get("title", "")
                url = entry.get("link", "")
                body = entry.get("summary", "")[:500]
                matched = keywords_matched(title + " " + body)
                if matched:
                    signal_id = md5_id(title, url)
                    upvotes = 0
                    signals.append({
                        "id": signal_id,
                        "source": "reddit",
                        "title": title,
                        "url": url,
                        "body_snippet": body,
                        "upvotes": upvotes,
                        "fetched_at": datetime.now(timezone.utc).isoformat(),
                        "keywords_matched": matched,
                    })
        except Exception as e:
            console.print(f"[yellow]Reddit feed error ({feed_url}): {e}[/yellow]")
    console.print(f"  Reddit: {len(signals)} signals found")
    return signals


def scan_hn() -> list:
    signals = []
    console.print("[bold cyan]Scanning Hacker News Algolia API...[/bold cyan]")
    for term in HN_SEARCH_TERMS:
        try:
            resp = requests.get(
                "https://hn.algolia.com/api/v1/search_by_date",
                params={"query": term, "tags": "story", "hitsPerPage": 20},
                headers=HEADERS,
                timeout=10,
            )
            if resp.status_code == 200:
                for hit in resp.json().get("hits", []):
                    title = hit.get("title", "")
                    url = hit.get("url") or f"https://news.ycombinator.com/item?id={hit.get('objectID')}"
                    body = (hit.get("story_text") or "")[:500]
                    matched = keywords_matched(title + " " + body)
                    if matched or term in title.lower():
                        signal_id = md5_id(title, url)
                        signals.append({
                            "id": signal_id,
                            "source": "hn",
                            "title": title,
                            "url": url,
                            "body_snippet": body,
                            "upvotes": hit.get("points", 0),
                            "fetched_at": datetime.now(timezone.utc).isoformat(),
                            "keywords_matched": matched or [term],
                        })
        except Exception as e:
            console.print(f"[yellow]HN API error (term={term}): {e}[/yellow]")
    console.print(f"  Hacker News: {len(signals)} signals found")
    return signals


def scan_gtrends() -> list:
    signals = []
    console.print("[bold cyan]Scanning Google Trends RSS...[/bold cyan]")
    for feed_url in GTRENDS_FEEDS:
        try:
            feed = feedparser.parse(feed_url)
            for entry in feed.entries[:30]:
                title = entry.get("title", "")
                url = entry.get("link", feed_url)
                OPERATOR_KEYWORDS = ["CSV", "Python", "SAP", "automation", "ERP", "Excel", "template", "script"]
                if any(kw.lower() in title.lower() for kw in OPERATOR_KEYWORDS):
                    signal_id = md5_id(title, url)
                    signals.append({
                        "id": signal_id,
                        "source": "gtrends",
                        "title": title,
                        "url": url,
                        "body_snippet": "",
                        "upvotes": 0,
                        "fetched_at": datetime.now(timezone.utc).isoformat(),
                        "keywords_matched": [kw for kw in OPERATOR_KEYWORDS if kw.lower() in title.lower()],
                    })
        except Exception as e:
            console.print(f"[yellow]Google Trends error: {e}[/yellow]")
    console.print(f"  Google Trends: {len(signals)} signals found")
    return signals


def main() -> None:
    IDEAS_DIR.mkdir(parents=True, exist_ok=True)

    seen = load_seen()
    existing = load_existing()
    existing_ids = {s["id"] for s in existing}

    all_new = scan_reddit() + scan_hn() + scan_gtrends()

    added = 0
    for signal in all_new:
        if signal["id"] not in seen and signal["id"] not in existing_ids:
            existing.append(signal)
            seen.add(signal["id"])
            existing_ids.add(signal["id"])
            added += 1

    RAW_SIGNALS_FILE.write_text(json.dumps(existing, indent=2))
    save_seen(seen)

    console.print(f"\n[bold green]Scan complete.[/bold green] {added} new signals added. Total: {len(existing)}")

    # Show top signals by upvotes
    table = Table(title="Top 10 Pain Signals")
    table.add_column("#", style="dim")
    table.add_column("Source", style="cyan")
    table.add_column("Title", style="white", max_width=60)
    table.add_column("Keywords", style="yellow")
    table.add_column("Upvotes", justify="right")

    top = sorted(existing, key=lambda x: x.get("upvotes", 0), reverse=True)[:10]
    for i, s in enumerate(top, 1):
        table.add_row(
            str(i),
            s["source"],
            s["title"][:60],
            ", ".join(s["keywords_matched"][:3]),
            str(s["upvotes"]),
        )
    console.print(table)


if __name__ == "__main__":
    main()
